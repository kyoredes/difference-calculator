from generate_diff import diff
path1, path2 = '/python-project-50/gendiff/scripts/json-files/file1.json', '/python-project-50/gendiff/scripts/json-files/file2.json'  # noqa: E501
print(diff(path1, path2))
