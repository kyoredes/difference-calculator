from generate_diff import diff
path1, path2 = '/python-project-50/gendiff/scripts/json-files/file1.json', '/python-project-50/gendiff/scripts/json-files/file2.json'
print(diff(path1, path2))

