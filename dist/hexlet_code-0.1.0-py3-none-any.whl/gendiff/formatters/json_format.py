import json


def build_json(data):
    return json.dumps(data, indent=4)
