from gendiff.app import main as generate_diff
