from gendiff.scripts.generate_diff import main as generate_diff
