from generate_diff import diff
print(diff('python-project-50/gendiff/json-files/file1.json', 'python-project-50/gendiff/json-files/file2.json'))

